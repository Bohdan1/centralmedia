<!--header-->
<?php get_header() ?>

<!--second-slider-->
<?php get_template_part('second', 'slider') ?>


<!--content-home-->
<?php get_template_part('content', 'home') ?>


<!--content-footer-->
<?php get_template_part('content', 'footer') ?>

<!--footer-->
<?php get_footer() ?>
