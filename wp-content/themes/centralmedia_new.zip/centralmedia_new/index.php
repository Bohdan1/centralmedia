<?php 
	//header
	get_header();

	//content-home
	get_template_part('content', 'home');

	//footer
	get_footer();
?>
