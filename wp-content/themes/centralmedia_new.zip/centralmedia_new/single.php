<?php get_header(); ?>
	<div> <?php the_title(); ?> </div>
<?php get_footer(); ?>