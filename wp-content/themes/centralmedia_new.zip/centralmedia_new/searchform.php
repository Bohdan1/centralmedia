<form class="search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
  <input type="search" placeholder="Пошук..." required name="s">
</form>