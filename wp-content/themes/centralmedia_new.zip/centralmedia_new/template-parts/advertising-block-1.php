<?php
	echo '
		<div class="advertisment-block">
        	<a href="' . get_option('block1_advertising_url') . '" target="_blank">
        		<img class="advertisment-img" src="' . get_option('block1_advertising_img') . '" alt="Логотип">
        	</a>
    	</div>';
?>