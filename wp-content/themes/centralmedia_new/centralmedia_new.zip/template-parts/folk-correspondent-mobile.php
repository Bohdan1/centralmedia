<div class="nar-kor-mob">
	<div class="nar-kor-block">
		<div class="nar-kor-img-mob">
			<img alt="img" class="user-video-width" src="<?php echo get_the_post_thumbnail_url( '', 'medium' ); ?>">
		</div>
		<div class="nar-kor-text-mob">
			<?php
				echo short_post_desc( 400 );
			?>
		</div>
	</div>
</div>